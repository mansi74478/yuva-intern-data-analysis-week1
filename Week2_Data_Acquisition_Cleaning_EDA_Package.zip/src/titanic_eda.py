"""Task 2: Data acquisition, cleaning and EDA on the public Titanic dataset.
Run: python src/titanic_eda.py
The script downloads the original public CSV, writes raw/cleaned data and charts.
"""
from pathlib import Path
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
FIG = ROOT / "visualizations"
DATA.mkdir(exist_ok=True)
FIG.mkdir(exist_ok=True)
URL = "https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv"

# 1. Acquire data from the public source
raw = pd.read_csv(URL)
raw.to_csv(DATA / "titanic_raw.csv", index=False)
print("Raw shape:", raw.shape)
print("Missing values before cleaning:\n", raw.isna().sum())
print("Exact duplicate rows:", raw.duplicated().sum())

# 2. Standardize column labels and clean obvious whitespace in text columns
clean = raw.copy()
clean.columns = clean.columns.str.strip()
for col in clean.select_dtypes(include="object").columns:
    clean[col] = clean[col].map(lambda x: x.strip() if isinstance(x, str) else x)

# 3. Remove exact duplicate rows (if any) and validate numeric values
clean = clean.drop_duplicates().copy()
for col in ["Age", "Fare", "SibSp", "Parch", "Pclass", "Survived"]:
    clean[col] = pd.to_numeric(clean[col], errors="coerce")
# Negative age/fare are invalid; set to missing before imputation
clean.loc[clean["Age"] < 0, "Age"] = np.nan
clean.loc[clean["Fare"] < 0, "Fare"] = np.nan

# 4. Missing-value treatment: median for numeric Age/Fare; mode for Embarked.
# Cabin is excluded from the analysis copy because most entries are missing;
# the original raw file remains preserved in data/titanic_raw.csv.
clean["Age"] = clean["Age"].fillna(clean["Age"].median())
clean["Fare"] = clean["Fare"].fillna(clean["Fare"].median())
if clean["Embarked"].isna().any():
    clean["Embarked"] = clean["Embarked"].fillna(clean["Embarked"].mode().iloc[0])
clean = clean.drop(columns=["Cabin"], errors="ignore")

# 5. Add useful derived fields and save cleaned data
clean["FamilySize"] = clean["SibSp"].fillna(0) + clean["Parch"].fillna(0) + 1
clean["SurvivalLabel"] = clean["Survived"].map({0: "Did not survive", 1: "Survived"})
clean.to_csv(DATA / "titanic_cleaned.csv", index=False)
print("Clean shape:", clean.shape)
print("Missing values after cleaning:\n", clean.isna().sum())

# 6. Exploratory analysis and figures
survival_counts = clean["Survived"].value_counts().reindex([0, 1], fill_value=0)
plt.figure(figsize=(7, 4))
plt.bar(["Did not survive", "Survived"], survival_counts.values)
plt.title("Passenger Survival Count"); plt.ylabel("Passengers"); plt.tight_layout()
plt.savefig(FIG / "survival_count.png", dpi=160); plt.close()
sex_rate = clean.groupby("Sex", dropna=False)["Survived"].mean().mul(100).sort_values(ascending=False)
plt.figure(figsize=(7, 4)); plt.bar(sex_rate.index.astype(str), sex_rate.values)
plt.title("Survival Rate by Sex"); plt.ylabel("Survival rate (%)"); plt.ylim(0, 100); plt.tight_layout()
plt.savefig(FIG / "survival_by_sex.png", dpi=160); plt.close()
class_rate = clean.groupby("Pclass")["Survived"].mean().mul(100)
plt.figure(figsize=(7, 4)); plt.bar([f"{i} class" for i in class_rate.index], class_rate.values)
plt.title("Survival Rate by Passenger Class"); plt.ylabel("Survival rate (%)"); plt.ylim(0, 100); plt.tight_layout()
plt.savefig(FIG / "survival_by_class.png", dpi=160); plt.close()

summary = pd.DataFrame({"metric": ["rows", "columns_before_cleaning", "survivors", "overall_survival_rate_pct"],
                        "value": [len(raw), raw.shape[1], int(clean["Survived"].sum()), round(clean["Survived"].mean()*100, 2)]})
summary.to_csv(DATA / "eda_summary.csv", index=False)
print("Survival rate by sex (%):\n", (clean.groupby("Sex")["Survived"].mean()*100).round(2))
print("Survival rate by class (%):\n", (clean.groupby("Pclass")["Survived"].mean()*100).round(2))
print("Saved raw data, cleaned data, summary and visualizations in project folders.")
