# Task 2 — Data Acquisition, Cleaning and Exploratory Data Analysis

## Project overview
This project uses the public Titanic passenger dataset to demonstrate data acquisition, quality checks, cleaning, and exploratory data analysis (EDA). The dataset has 891 passenger records and 12 original fields in the commonly used training CSV.

## Dataset source
https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv

## Files
- `Task2_Data_Acquisition_Cleaning_EDA_Report.docx` — report for review/submission.
- `src/titanic_eda.py` — reproducible script that downloads the original CSV and performs cleaning/EDA.
- `data/` — raw and cleaned CSV files are created when the script runs.
- `visualizations/` — charts included in the report; the script recreates them from the downloaded data.

## Run the analysis
1. Install Python 3.10+ and packages: `pip install -r requirements.txt`
2. From this folder run: `python src/titanic_eda.py`
3. The script needs an internet connection to download the public CSV.

## Cleaning decisions
- Preserve the downloaded raw CSV for traceability.
- Strip whitespace from text values and column labels.
- Remove exact duplicate rows if present.
- Convert analysis fields to numeric types and treat invalid negative age/fare as missing.
- Impute missing `Age` and `Fare` with medians; fill missing `Embarked` with its mode.
- Exclude `Cabin` from the cleaned analysis copy because it is heavily incomplete; the raw copy is retained.
- Create `FamilySize` and a readable survival label.

## Important note
Charts in the report are summary visualizations of the standard Titanic training dataset. Run the Python script to regenerate all counts and charts directly from the source CSV on your own computer.
